"""Compare identical held-out customer-service prompts: base vs LoRA.

Exact match and token F1 are rough lexical signals, not measures of correctness.
Review outputs manually and add safety, hallucination and out-of-scope checks.
"""
import gc
import json
import os
import re
from collections import Counter
from pathlib import Path

import torch
from peft import PeftModel
from transformers import AutoModelForCausalLM, AutoTokenizer

MODEL_ID = os.getenv("MODEL_ID", "google/gemma-3-270m-it")
OUT = Path(os.getenv("OUTPUT_DIR", "artifacts"))
MAX_TEST = int(os.getenv("MAX_TEST", "100"))


def norm(s):
    return re.findall(r"\w+", s.lower())


def token_f1(pred, reference):
    a, b = Counter(norm(pred)), Counter(norm(reference))
    overlap = sum((a & b).values())
    precision = overlap / sum(a.values()) if a else 0.0
    recall = overlap / sum(b.values()) if b else 0.0
    return 2 * precision * recall / (precision + recall) if precision + recall else 0.0


def generate(model, tokenizer, prompt):
    tokens = tokenizer.apply_chat_template(
        [{"role": "user", "content": prompt}],
        add_generation_prompt=True, tokenize=True, return_tensors="pt"
    ).to(next(model.parameters()).device)
    with torch.inference_mode():
        generated = model.generate(
            input_ids=tokens,
            max_new_tokens=128,
            do_sample=False,
            pad_token_id=tokenizer.pad_token_id,
        )
    return tokenizer.decode(generated[0, tokens.shape[-1]:], skip_special_tokens=True).strip()


def run_eval(test, tokenizer, adapter=None):
    model = AutoModelForCausalLM.from_pretrained(
        MODEL_ID, dtype=torch.float16, device_map="auto", attn_implementation="sdpa"
    )
    if adapter:
        model = PeftModel.from_pretrained(model, str(adapter))
    model.eval()
    scores = []
    for row in test:
        predicted = generate(model, tokenizer, row["instruction"])
        scores.append({
            "instruction": row["instruction"],
            "expected": row["response"],
            "predicted": predicted,
            "exact_match": norm(predicted) == norm(row["response"]),
            "token_f1": token_f1(predicted, row["response"]),
        })
    del model
    gc.collect()
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
    return scores


def report(rows):
    return {
        "count": len(rows),
        "exact_match": round(sum(x["exact_match"] for x in rows) / len(rows), 4),
        "mean_token_f1": round(sum(x["token_f1"] for x in rows) / len(rows), 4),
    }


def main():
    if not torch.cuda.is_available():
        raise RuntimeError("This tutorial requires a CUDA GPU")
    tokenizer = AutoTokenizer.from_pretrained(MODEL_ID)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    with (OUT / "test.jsonl").open(encoding="utf-8") as f:
        test = [json.loads(line) for line in f][:MAX_TEST]
    if not test:
        raise ValueError("No test examples found")
    base = run_eval(test, tokenizer)
    tuned = run_eval(test, tokenizer, OUT / "gemma-lora-adapter")
    results = {
        "base": report(base),
        "lora": report(tuned),
        "cases": [
            {"instruction": a["instruction"], "expected": a["expected"],
             "base": a["predicted"], "lora": b["predicted"]}
            for a, b in zip(base, tuned)
        ],
    }
    (OUT / "comparison.json").write_text(
        json.dumps(results, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps({"base": results["base"], "lora": results["lora"]}, indent=2))
    print("Review detailed cases in", OUT / "comparison.json")


if __name__ == "__main__":
    main()

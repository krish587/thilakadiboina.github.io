# Can AI Improve Itself? — Article + Gemma starter experiment

This package accompanies a plain-language website article comparing three ways to improve smaller AI models:

1. **LoRA:** supervised fine-tuning with question/answer examples; implemented by the included Python scripts.
2. **WISD:** self-distillation using contrast with a weakened copy; early research, **not implemented here for Gemma**.
3. **Weight-Space Programming:** targeted direct editing of weights by another AI; early research, **not implemented here for Gemma**.

## Website files

- `article.html`: standalone responsive article for a static website.
- `article.md`: Markdown version with front matter; edit for your website.
- `linkedin_post.md`: short social post; replace `[My website link]` after publishing.
- `gemma_three_ways_code.zip`: scripts; the article HTML expects it in the same folder.

## Code files

- `train_gemma_lora.py`: public Bitext customer-support dataset → dedupe → train/validation/test split → LoRA adapter; also accepts `DATA_CSV=my_support_examples.csv` to use your own approved training examples.
- `evaluate_gemma.py`: generate original-vs-LoRA answers on held-out test questions, save a side-by-side review file, show simple (limited) lexical scores.
- `requirements.txt`: baseline dependencies. Install GPU-compatible PyTorch separately.
- `sample_training_data.csv`: just enough to illustrate CSV format; not adequate to prove model gains.

## Run the public dataset example

Use a CUDA GPU environment, Python, and a compatible PyTorch build. Accept the Gemma model terms at https://huggingface.co/google/gemma-3-270m-it and authenticate:

```bash
python -m pip install -r requirements.txt
hf auth login
python train_gemma_lora.py
python evaluate_gemma.py
```

This defaults to up to 6,000 records, with approximate 80/10/10 splits. Outputs go under `artifacts/`.

## Use your own approved questions and answers

Create a CSV with columns `instruction` and `response`. Run:

```bash
DATA_CSV=my_support_examples.csv python train_gemma_lora.py
python evaluate_gemma.py
```

Do not use sensitive/private customer data or unapproved company files in a public GPU environment. Changing facts should come from a trusted current source, not only fine-tuning. Validate response accuracy and safety before deployment.

## Important limits

- Python syntax checked; **not executed in a GPU training environment** and no training results claimed.
- Close paraphrases may leak across this starter project's random splits. Remove near-duplicates and construct a genuinely unseen test set for any real benchmark.
- The built-in lexical scores cannot validate truthfulness or customer-support quality. Add manual review, out-of-domain questions, and regression tests.
- WISD code is available from https://github.com/jet-ai-projects/WISD, but its public reference workflow targets Qwen and documents a multi-GPU training setup. This package does **not** claim a working Gemma WISD port.
- The original Weight-Space Programming study reported little improvement for Gemma 3 270M; this package does **not** claim direct weight-editing success.
- Bitext dataset uses CDLA-Sharing-1.0; Gemma has its own license. Check use and redistribution terms for each.

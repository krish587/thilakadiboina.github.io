"""Reference LoRA training experiment, NOT weight-space programming.

Runs with access to the gated google/gemma-3-270m-it model and a CUDA GPU.
Install a compatible CUDA PyTorch build and requirements.txt first.
No claim of benchmarking or execution is made in the associated article.
"""
import json
import os
import random
from pathlib import Path

import torch
from datasets import load_dataset
from peft import LoraConfig
from transformers import AutoModelForCausalLM, AutoTokenizer
from trl import SFTConfig, SFTTrainer

SEED = 42
MODEL_ID = os.getenv("MODEL_ID", "google/gemma-3-270m-it")
DATASET_ID = "bitext/Bitext-customer-support-llm-chatbot-training-dataset"
OUT = Path(os.getenv("OUTPUT_DIR", "artifacts"))
N_EXAMPLES = int(os.getenv("N_EXAMPLES", "6000"))
CUSTOM_CSV = os.getenv("DATA_CSV")  # Optional local CSV: instruction,response


def build_data():
    if CUSTOM_CSV:
        raw = load_dataset("csv", data_files=CUSTOM_CSV, split="train")
    else:
        raw = load_dataset(DATASET_ID, split="train")
    required = {"instruction", "response"}
    if not required.issubset(set(raw.column_names)):
        raise ValueError("The dataset must have instruction and response columns")
    # An initial deduplication safeguard; near-paraphrases still need auditing.
    seen = set()
    keep = []
    for i, r in enumerate(raw):
        instruction = r.get("instruction") or ""
        answer = r.get("response") or ""
        key = " ".join(str(instruction).lower().split())
        if key and key not in seen and str(answer).strip():
            seen.add(key)
            keep.append(i)
    raw = raw.select(keep).shuffle(seed=SEED)
    if len(raw) < 30:
        raise ValueError("Need at least 30 distinct labelled examples for this demo (more is better).")
    raw = raw.select(range(min(N_EXAMPLES, len(raw))))
    split = raw.train_test_split(test_size=0.20, seed=SEED)
    holdout = split["test"].train_test_split(test_size=0.50, seed=SEED)

    def to_chat(row):
        return {
            "prompt": [{"role": "user", "content": row["instruction"]}],
            "completion": [{"role": "assistant", "content": row["response"]}],
        }

    train = split["train"].map(to_chat, remove_columns=split["train"].column_names)
    valid = holdout["train"].map(to_chat, remove_columns=holdout["train"].column_names)
    OUT.mkdir(parents=True, exist_ok=True)
    # Unlabeled *training* prompts for an independent self-distillation experiment.
    # Keep the held-out test questions out of every training or prompt-curation run.
    with (OUT / "train_prompts.jsonl").open("w", encoding="utf-8") as f:
        for r in train:
            f.write(json.dumps({"prompt": r["prompt"][0]["content"]}, ensure_ascii=False) + "\n")
    with (OUT / "test.jsonl").open("w", encoding="utf-8") as f:
        for r in holdout["test"]:
            f.write(json.dumps({"instruction": r["instruction"],
                                "response": r["response"],
                                "intent": r.get("intent")}, ensure_ascii=False) + "\n")
    (OUT / "experiment.json").write_text(json.dumps({
        "model": MODEL_ID,
        "dataset": CUSTOM_CSV or DATASET_ID,
        "seed": SEED,
        "requested_example_count": N_EXAMPLES,
        "deduplicated_sample_count": len(raw),
        "train_count": len(train),
        "validation_count": len(valid),
        "test_count": len(holdout["test"]),
    }, indent=2), encoding="utf-8")
    return train, valid


def main():
    if not torch.cuda.is_available():
        raise RuntimeError("This tutorial is configured for a CUDA GPU. Use a GPU runtime.")
    random.seed(SEED)
    torch.manual_seed(SEED)
    train, valid = build_data()
    tokenizer = AutoTokenizer.from_pretrained(MODEL_ID)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    model = AutoModelForCausalLM.from_pretrained(
        MODEL_ID, dtype=torch.float16, attn_implementation="sdpa"
    )
    model.config.use_cache = False
    lora = LoraConfig(
        r=8, lora_alpha=16, lora_dropout=0.05, bias="none",
        target_modules=["q_proj", "v_proj"], task_type="CAUSAL_LM"
    )
    config = SFTConfig(
        output_dir=str(OUT / "checkpoints"),
        seed=SEED,
        num_train_epochs=1,
        learning_rate=2e-4,
        per_device_train_batch_size=2,
        gradient_accumulation_steps=8,
        per_device_eval_batch_size=2,
        max_length=384,
        completion_only_loss=True,
        eval_strategy="steps",
        eval_steps=100,
        save_strategy="steps",
        save_steps=100,
        save_total_limit=2,
        logging_steps=20,
        gradient_checkpointing=True,
        fp16=True,
        bf16=False,
        report_to="none",
    )
    trainer = SFTTrainer(
        model=model,
        args=config,
        train_dataset=train,
        eval_dataset=valid,
        peft_config=lora,
        processing_class=tokenizer,
    )
    trainer.train()
    trainer.model.save_pretrained(str(OUT / "gemma-lora-adapter"))
    tokenizer.save_pretrained(str(OUT / "gemma-lora-adapter"))
    print("Validation:", trainer.evaluate())
    print("Saved adapter and held-out test examples under", OUT)


if __name__ == "__main__":
    main()
